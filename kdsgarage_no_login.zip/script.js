
const firebaseConfig = {
  apiKey: "AIzaSyCZRKv8dvCHRHU6jZx7jJmgmZiip5VVo0A",
  authDomain: "kds-garage.firebaseapp.com",
  projectId: "kds-garage",
  storageBucket: "kds-garage.appspot.com",
  messagingSenderId: "874166888350",
  appId: "1:874166888350:web:a716571214a7a4193f988f",
  measurementId: "G-WK0Z32CBXM"
};
firebase.initializeApp(firebaseConfig);
const storage = firebase.storage();

function uploadImage(event) {
  const file = event.target.files[0];
  if (!file) return;

  const ref = storage.ref("public/" + file.name);
  ref.put(file).then(() => {
    alert("Upload complete!");
    loadImages();
  });
}

function loadImages() {
  const ref = storage.ref("public/");
  ref.listAll().then(result => {
    const gallery = document.getElementById("gallery");
    gallery.innerHTML = "";
    result.items.forEach(item => {
      item.getDownloadURL().then(url => {
        const img = document.createElement("img");
        img.src = url;
        gallery.appendChild(img);
      });
    });
  });
}

// Load images on page load
window.onload = loadImages;
